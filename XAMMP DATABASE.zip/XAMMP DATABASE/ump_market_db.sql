-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2026 at 01:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ump_market_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE `conversations` (
  `id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_message_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `conversations`
--

INSERT INTO `conversations` (`id`, `buyer_id`, `seller_id`, `product_id`, `created_at`, `last_message_at`) VALUES
(1, 7, 6, 1, '2025-09-25 10:43:27', '2025-09-25 22:48:48'),
(2, 4, 6, 1, '2025-09-25 22:47:50', '2025-09-25 22:48:26'),
(4, 2, 6, 22, '2025-09-27 20:26:10', '2025-09-27 20:26:10'),
(5, 7, 6, 23, '2025-09-27 22:08:28', '2025-09-27 22:08:28'),
(7, 7, 8, NULL, '2025-10-02 18:12:52', '2025-10-02 18:12:52'),
(8, 6, 8, NULL, '2025-10-02 21:16:32', '2025-10-02 21:16:32'),
(9, 4, 6, 22, '2025-10-02 22:53:40', '2025-10-02 22:53:40'),
(10, 4, 6, 23, '2025-10-05 16:31:43', '2025-10-05 16:31:43'),
(11, 4, 2, 2, '2025-10-06 15:50:35', '2025-10-06 15:50:35'),
(19, 7, 2, 20, '2025-10-14 08:28:54', '2025-10-14 08:28:54'),
(20, 11, 6, 23, '2025-10-27 06:44:58', '2025-10-27 06:44:58'),
(21, 11, 2, 20, '2025-10-27 06:46:58', '2025-10-27 06:46:58'),
(22, 2, 8, NULL, '2025-10-27 06:48:19', '2025-10-27 06:48:19'),
(23, 14, 6, 23, '2025-10-27 07:54:00', '2025-10-27 07:54:00'),
(24, 14, 2, 20, '2025-10-27 08:00:23', '2025-10-27 08:00:23'),
(25, 14, 6, 32, '2025-10-27 08:08:13', '2025-10-27 08:08:13'),
(26, 2, 6, 23, '2025-11-11 16:30:51', '2025-11-13 22:07:48'),
(27, 6, 2, 21, '2025-11-12 08:54:31', '2025-11-12 08:54:31'),
(28, 5, 2, 21, '2025-11-12 22:04:36', '2025-11-12 22:07:29'),
(29, 6, 2, 33, '2025-11-14 06:53:48', '2025-11-14 06:55:52'),
(30, 16, 2, 33, '2025-11-14 07:56:32', '2025-11-14 07:56:32');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `conversation_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `content` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `conversation_id`, `sender_id`, `content`, `created_at`, `is_read`) VALUES
(2, 2, 4, 'bhuti', '2025-09-25 22:47:50', 1),
(3, 2, 6, 'khambamn', '2025-09-25 22:48:26', 0),
(4, 1, 6, 'moja', '2025-09-25 22:48:48', 1),
(6, 4, 2, 'buya', '2025-09-27 20:26:10', 0),
(7, 5, 7, 'how much', '2025-09-27 22:08:28', 1),
(9, 7, 7, 'Subject: hi\nType: general\n\nhi', '2025-10-02 18:12:52', 1),
(10, 8, 6, 'Subject: hi\nType: general\n\nyebo', '2025-10-02 21:16:32', 1),
(11, 9, 4, 'Is this item still available?', '2025-10-02 22:53:40', 0),
(12, 10, 4, 'Are you available to meet on campus?', '2025-10-05 16:31:43', 0),
(13, 11, 4, 'Are you available to meet on campus?', '2025-10-06 15:50:35', 1),
(21, 19, 7, 'Can you provide more details about the condition?', '2025-10-14 08:28:54', 0),
(22, 20, 11, 'Is this item still available?', '2025-10-27 06:44:58', 0),
(23, 21, 11, 'Is this item still available?', '2025-10-27 06:46:58', 0),
(24, 22, 2, 'Subject: how do i add more products\nType: general\n\nggwkuhkgv bxhg b', '2025-10-27 06:48:19', 0),
(25, 23, 14, 'hi is it available', '2025-10-27 07:54:00', 0),
(26, 24, 14, 'Are you available to meet on campus?', '2025-10-27 08:00:23', 1),
(27, 25, 14, 'Can you provide more details about the condition?', '2025-10-27 08:08:13', 0),
(28, 26, 2, 'Are you available to meet on campus?', '2025-11-11 16:30:51', 1),
(29, 26, 6, 'hey', '2025-11-12 08:46:09', 1),
(30, 26, 6, 'now', '2025-11-12 08:46:37', 1),
(31, 26, 6, 'hey', '2025-11-12 08:52:17', 1),
(32, 27, 6, 'Are you available to meet on campus?', '2025-11-12 08:54:31', 0),
(33, 26, 6, 'hey you', '2025-11-12 08:58:00', 1),
(34, 26, 6, 'hey', '2025-11-12 18:50:44', 1),
(35, 26, 6, 'ola', '2025-11-12 18:50:53', 1),
(36, 26, 6, 'sure', '2025-11-12 21:38:15', 1),
(37, 26, 6, 'ola', '2025-11-12 21:53:56', 1),
(38, 26, 6, 'eita', '2025-11-12 21:55:18', 1),
(39, 26, 2, 'ola', '2025-11-12 21:57:55', 1),
(40, 28, 5, 'Are you available to meet on campus?', '2025-11-12 22:04:36', 0),
(41, 28, 5, 'ola', '2025-11-12 22:07:11', 0),
(42, 28, 5, 'eita', '2025-11-12 22:07:29', 0),
(43, 26, 6, 'thaa', '2025-11-13 22:07:48', 0),
(44, 29, 6, 'momo', '2025-11-14 06:53:48', 1),
(45, 29, 2, 'hi', '2025-11-14 06:55:52', 0),
(46, 30, 16, 'hi', '2025-11-14 07:56:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`, `created_at`, `expires_at`, `used`) VALUES
(1, '230633323@ump.ac.za', '7rxs9nbswW-fhkyoYOZYq9Gup3W8hGyg9QMCitddyYg', '2025-10-26 23:47:13', '2025-10-27 02:47:13', 1),
(2, '230633323@ump.ac.za', 'RsFAjMEFxGEHKODYkT5T5_IoBJK5EXti6rSR_vT5SkQ', '2025-10-27 06:53:45', '2025-10-27 09:53:45', 1),
(3, '230633323@ump.ac.za', 'wIE_SNWa0SpywNqzg8HVEXcW9EbMfzc5LljoHljN5CY', '2025-11-12 22:01:42', '2025-11-13 01:01:42', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `product_condition` varchar(50) DEFAULT NULL,
  `image_path` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','sold_out') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `quantity` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `seller_id`, `title`, `description`, `price`, `category`, `product_condition`, `image_path`, `status`, `created_at`, `quantity`) VALUES
(1, 6, 'Traditional clothing', 'Traditional clothing', 800.00, 'Clothing', 'New', 'uploads/6_1758796855_552652261_10239631853243538_1877497360240388735_n.jpg', 'approved', '2025-09-25 10:40:55', 1),
(2, 2, 'Make up services', 'I do Make up', 100.00, 'Services', 'New', 'uploads/2_1758852307_Make_up_kit_2.jpg', 'approved', '2025-09-26 02:05:07', 1),
(3, 2, 'Note pad', 'for taking notes', 40.00, 'Other', 'New', 'uploads/2_1758852365_Book.jpg', 'approved', '2025-09-26 02:06:05', 1),
(4, 2, 'Headphones', 'Razor headphones', 300.00, 'Electronics', 'New', 'uploads/2_1758852418_Hadphones_R.jpg', 'approved', '2025-09-26 02:06:58', 1),
(5, 2, 'Smart watch', 'Apple product', 600.00, 'Electronics', 'New', 'uploads/2_1758852524_Smart_Watch.jpg', 'approved', '2025-09-26 02:08:44', 1),
(6, 2, '3 Products', 'A mac book , Headphones and a digital camera', 11000.00, 'Electronics', 'Like New', 'uploads/2_1758852645_All_3.jpg', 'approved', '2025-09-26 02:10:45', 1),
(7, 2, 'Apple Iphone', 'iPhone 5', 1800.00, 'Electronics', 'Good', 'uploads/2_1758852713_I_phone.jpg', 'approved', '2025-09-26 02:11:53', 1),
(8, 4, 'Joy pad', 'PC Joy pad', 100.00, 'Electronics', 'Fair', 'uploads/4_1758852804_Joy_pad_1.jpg', 'approved', '2025-09-26 02:13:24', 1),
(9, 4, 'Apple Mac Book', 'Mac book 13', 9000.00, 'Electronics', 'Good', 'uploads/4_1758852858_Mac_book.jpg', 'approved', '2025-09-26 02:14:18', 1),
(10, 4, 'Camera', 'Classic camera', 2000.00, 'Electronics', 'Good', 'uploads/4_1758852917_Classic_Camera_0.jpg', 'approved', '2025-09-26 02:15:17', 1),
(11, 4, 'PC Kit', 'Wired headphones, a keyboard ,notebook and a mouse', 900.00, 'Electronics', 'Like New', 'uploads/4_1758853018_PC_Kit.jpg', 'approved', '2025-09-26 02:16:58', 1),
(12, 6, '2 Joypads', 'PS4/PCjoypads', 600.00, 'Electronics', 'Like New', 'uploads/6_1758853165_PS_4_2_Joypad.jpg', 'approved', '2025-09-26 02:19:25', 1),
(13, 6, 'Joypad', 'PS4/PC Joypad', 400.00, 'Electronics', 'New', 'uploads/6_1758853227_PS4_1_Joypad.jpg', 'approved', '2025-09-26 02:20:27', 1),
(14, 6, 'Joypad', 'wired Xbox/PC joypad', 200.00, 'Electronics', 'Fair', 'uploads/6_1758853301_X_Box_wired.jpg', 'approved', '2025-09-26 02:21:41', 1),
(15, 6, 'iMAC', 'Apple iMAC A1418 All-in-One Desktop – Intel Core i5, 8GB RAM, 1TB HDD, 21.5″ FHD Display, Mac OS Catalina, USB Keyboard & Mouse (Certified Refurbished)', 7000.00, 'Electronics', 'Good', 'uploads/6_1758853403_All_in1_Mac.jpg', 'approved', '2025-09-26 02:23:23', 1),
(16, 6, '3 Iterms', 'Mac book, Digital Camera and an iPhone 4', 10000.00, 'Electronics', 'Good', 'uploads/6_1758853485_Combo_1.jpg', 'approved', '2025-09-26 02:24:45', 1),
(17, 6, 'Headphones', 'wired Headphones', 400.00, 'Electronics', 'Good', 'uploads/6_1758853541_Headphones_S.jpg', 'approved', '2025-09-26 02:25:41', 1),
(18, 6, 'Camera', 'Digital camera', 1000.00, 'Electronics', 'Fair', 'uploads/6_1758853597_Digital_Camera.jpg', 'approved', '2025-09-26 02:26:37', 1),
(19, 6, 'IPhone', 'iPhone 5 and airpods', 3000.00, 'Electronics', 'New', 'uploads/6_1758853666_I_Phone_6.jpg', 'approved', '2025-09-26 02:27:46', 1),
(20, 2, 'Headphones', 'JBL Headphones', 600.00, 'Electronics', 'Good', 'uploads/2_1758853881_JBL_Heasphones.jpg', 'approved', '2025-09-26 02:31:21', 1),
(21, 2, 'edeee', 'eeeee', 444.00, 'Food', 'Like New', 'uploads/2_1758871042_Classic_Camera_0.jpg', 'approved', '2025-09-26 07:17:22', 11),
(22, 6, 'Gamer', 'Joypad', 100.00, 'Clothing', 'Fair', 'uploads/6_1758872620_Joy_pad_1.jpg', 'sold_out', '2025-09-26 07:43:40', 0),
(23, 6, 'Camera', 'Classic Camera', 999.00, 'Food', 'Like New', 'uploads/6_1759003553_Classic_Camera_0.jpg', 'approved', '2025-09-27 20:05:53', 1),
(24, 6, 'Braids', 'Braids', 250.00, 'Services', 'New', 'uploads/6_1759681622_hq720.jpg', 'approved', '2025-10-02 13:55:52', 1),
(31, 6, 'ggg', 'hhhh', 888.00, 'Clothing', 'Like New', 'uploads/6_1759682147_Camera_classic.jpg', 'rejected', '2025-10-05 16:35:47', 1),
(32, 6, 'IOGH', 'KJB', 777.00, 'Other', 'New', 'uploads/6_1760294195_547290954_122184761648371153_6597075884176996973_n.jpg', 'sold_out', '2025-10-12 18:36:35', 0),
(33, 2, 'Calculus', 'Calculus Volume 1', 400.00, 'Textbooks', 'New', 'uploads/2_1763070551_61TTGzn6vuL._SL1500_.jpg', 'approved', '2025-11-13 21:49:11', 2),
(34, 2, 'PC', 'desktop', 25000.00, 'Electronics', 'Fair', 'uploads/2_1763107266_All_in1_Mac.jpg', 'approved', '2025-11-14 08:01:06', 2);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `review_text` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `product_id`, `seller_id`, `buyer_id`, `rating`, `review_text`, `created_at`) VALUES
(1, 20, 2, 6, 3, 'yibi', '2025-09-27 22:05:31'),
(2, 23, 6, 7, 3, 'yibi', '2025-09-27 22:06:26'),
(3, 24, 6, 7, 3, '', '2025-10-14 08:14:57'),
(4, 23, 6, 14, 5, '', '2025-10-27 07:52:55'),
(5, 33, 2, 16, 4, '', '2025-11-14 07:56:56');

-- --------------------------------------------------------

--
-- Table structure for table `seller_applications`
--

CREATE TABLE `seller_applications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_image_path` text NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seller_applications`
--

INSERT INTO `seller_applications` (`id`, `user_id`, `card_image_path`, `status`, `created_at`) VALUES
(1, 4, 'uploads/cards/4_1758755300_552652261_10239631853243538_1877497360240388735_n.jpg', 'approved', '2025-09-24 23:08:20'),
(2, 6, 'uploads/cards/6_1758789999_552652261_10239631853243538_1877497360240388735_n.jpg', 'approved', '2025-09-25 08:46:39');

-- --------------------------------------------------------

--
-- Table structure for table `seller_reports`
--

CREATE TABLE `seller_reports` (
  `id` int(11) NOT NULL,
  `reporter_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','reviewed','resolved') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `resolution_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seller_reports`
--

INSERT INTO `seller_reports` (`id`, `reporter_id`, `seller_id`, `product_id`, `reason`, `description`, `status`, `created_at`, `reviewed_at`, `reviewed_by`, `resolution_notes`) VALUES
(1, 7, 6, 1, 'other', 'yin le', 'resolved', '2025-09-25 21:04:46', '2025-09-25 22:40:58', 8, 'kim'),
(2, 2, 6, 19, 'suspicious_activity', 'kuhiuhiu', 'reviewed', '2025-09-26 06:43:04', '2025-11-14 07:24:35', 8, '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `is_seller` tinyint(1) DEFAULT 0,
  `premium_member` tinyint(1) DEFAULT 0,
  `is_admin` tinyint(1) DEFAULT 0,
  `blocked` tinyint(1) DEFAULT 0,
  `approved` tinyint(1) DEFAULT 0,
  `card_image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `location` varchar(100) DEFAULT NULL,
  `location_notes` text DEFAULT NULL,
  `lease_agreement_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `student_number`, `email`, `password`, `phone`, `is_seller`, `premium_member`, `is_admin`, `blocked`, `approved`, `card_image_path`, `created_at`, `location`, `location_notes`, `lease_agreement_path`) VALUES
(2, 'Jimmy Mlambo', '230633323', '230633323@ump.ac.za', 'scrypt:32768:8:1$IbEPdgRTxaGkVOps$bf73f18bc0acdecf34350b52ce2e1213bf10355567b5f52d1fe19d6a10cbaff18dd3b3c5e0b1554c647aff60b4eb091ca71d0a21df5704e8495b68ba3d59e000', '0664218291', 1, 0, 0, 0, 1, 'uploads/card_230633323_1758754168_ID3.png', '2025-09-24 22:49:28', NULL, NULL, NULL),
(4, 'Jimmy Mlambo', '230633324', '230633324@ump.ac.za', 'scrypt:32768:8:1$FlXqryA1LetGQ9oM$69e8d7ad122d651dc349d88c058b6862643173a84a446283f4484de77b79f70e26cc2ce5460c2b3929e202a154a6352ca1a2205e57929e50ae0ea996de018099', '0664218292', 1, 0, 0, 0, 1, 'uploads/card_230633324_1758755225_ID3.png', '2025-09-24 23:07:05', NULL, NULL, NULL),
(5, 'Jimmy Mlambo', '230633325', '230633325@ump.ac.za', 'scrypt:32768:8:1$5xAvogBtLNOgY9HV$c11000e6f192f9cbe32ba88c0093cb2189064734539cf373007be770cfdbeb28ce20c6230b46ca474808e97e10332c4cb003d8fce38a540415e2f093e8aa4aae', '0664218295', 0, 0, 0, 0, 1, 'uploads/card_230633325_1758757445_ID3.png', '2025-09-24 23:44:05', NULL, NULL, NULL),
(6, 'Jimmy Mlambo', '230633326', '230633326@ump.ac.za', 'scrypt:32768:8:1$3gvNYbt9VqJOZRRD$59f32bd52baeba704c764bcedda532e407fc6422d271525f37ffea94aed8892551a237768ae18695ea547bbad571a2421adad9b26f50def3e70d36c025f53257', '0664218296', 1, 0, 0, 0, 1, 'uploads/card_230633326_1758759173_ID3.png', '2025-09-25 00:12:53', 'Mbombela Campus', '28 Hawk Stone Henge', NULL),
(7, 'Malatsoa', '230567940', '230567940@ump.ac.za', 'scrypt:32768:8:1$4Vim4eJN1bQuAlrK$0fda66dc63f1e90819049ebddb4e3d8b73522f83373ae8d137ee6fbd5fe21b9785f7773bb1737b96405f05d3a5e455c2293c17e779a96f2e02a1efe48f017d0e', '0676357242', 0, 0, 0, 0, 1, 'uploads/card_230567940_1758788284_ID3.png', '2025-09-25 08:18:04', NULL, NULL, NULL),
(8, 'Admin User', '000000000', 'admin@umpmarket.com', 'scrypt:32768:8:1$k9bNA7m2pk5yxy0L$924d7634966b9c7e2bd1d596b6c69f52e5ac2b92200419656e37e001f9b45890b671267809202b645e53e38cbe28d5f47f3bc5453e5ed548ad1c315866a268fd', NULL, 0, 0, 1, 0, 1, NULL, '2025-09-25 08:21:00', NULL, NULL, NULL),
(9, 'buyer1', '222222222', '222222222@ump.ac.za', 'scrypt:32768:8:1$rYP9isS8eLSZX6Un$7bf38c18231a06e8fc82105d93090c6c5760c765ce236d6dce33823f2bfe3f320af9a5edb84f38e139c60c9380f922b15031b3137b8db76ecdd8a71e3c9ed078', '071 234 5678', 0, 0, 0, 0, 0, 'uploads/card_222222222_1758872432_ChatGPT_Image_Sep_19_2025_03_55_56_PM.png', '2025-09-26 07:40:32', NULL, NULL, NULL),
(10, 'Noxolo', '230633327', '230633327@ump.ac.za', 'scrypt:32768:8:1$Q1c5KbjL76yI7GpR$b57e539dde519d0c1d7e385765c3da0b51b4d97d63b9d4c8b639b621b50fc7dac33c3c4f9a0883f2e90981a34fc763a37974868f3dd03d70089a45210fada2e4', '230633326', 0, 0, 0, 0, 0, 'uploads/card_230633327_1759694763_ChatGPT_Image_Sep_19_2025_03_55_56_PM.png', '2025-10-05 20:06:03', 'Mbombela Campus', '1st residence room1', 'uploads/lease_230633327_1759694763_analytics_report_20251005_183330.pdf'),
(11, 'huli', '222603046', '222603046@ump.ac.za', 'scrypt:32768:8:1$FR0Z1wrppcGci3vq$aea1d63da434cf79808bd27c4aa331d6f4d01522cc8d487a84d4bc5dd8de0b35c90ff8722961f8cf75bd0fc62183744ad7d46912d1ed06827e6ec7e745fcf03c', '0614758918', 0, 0, 0, 1, 1, 'uploads/card_222603046_1761547294_ChatGPT_Image_Sep_19_2025_03_55_56_PM.png', '2025-10-27 06:42:11', 'Mbombela Campus', 'luhambo', 'uploads/lease_222603046_1761547294_NSFAS_Lease_Agreement_template_version_1_of_2025_approved_philani_success_gwebu_nsfas_accomodation_solution.pdf'),
(12, 'valencia', '230942091', '230942091@ump.ac.za', 'scrypt:32768:8:1$OOj2SNSxmAW4EvpL$77a3453267f7de27d4207c280d34d69b1b39a2e211fe2f9ac467406b2d6ecf7c23e78f4c23312e506b35844df67ff03bbc900aae1a1691b74d3bc0fcda68076d', '0664036257', 0, 0, 0, 0, 0, 'uploads/card_230942091_1761550337_ChatGPT_Image_Sep_19_2025_03_55_56_PM.png', '2025-10-27 07:33:05', 'Mbombela Campus', 'kamagugu', 'uploads/lease_230942091_1761550337_NSFAS_Lease_Agreement_template_version_1_of_2025_approved_philani_success_gwebu_nsfas_accomodation_solution.pdf'),
(14, 'Prince', '230305237', '230305237@ump.ac.za', 'scrypt:32768:8:1$RhvWBdKQBKclxJ8g$3cd3bfe165d35a4efc9fc8d6a09260f81ccc650fba9f445216a70071a9416ed6b831c4a6e4aef926895a7cc174c2cc7ba896084f7c56e7bad2a46d89d04ce565', '0712345678', 0, 0, 0, 0, 1, 'uploads/card_230305237_1761551308_ChatGPT_Image_Sep_19_2025_03_55_56_PM.png', '2025-10-27 07:49:02', 'Mbombela Campus', '', 'uploads/lease_230305237_1761551308_NSFAS_Lease_Agreement_template_version_1_of_2025_approved_philani_success_gwebu_nsfas_accomodation_solution.pdf'),
(15, 'Tshepi', '220202237', '220202237@ump.ac.za', 'scrypt:32768:8:1$ouWak24xgWoNaWRw$ddffd1b3a4ec53abd6373dae65c6de8c87181082ec3b9255e7e11d435aecd2650ee0dfe6001ce9f07dec94cea6e2d604bb53e01e0268e1d26ca0db5fc4ce6f13', '0664218291', 0, 0, 0, 0, 1, 'uploads/card_220202237_1763104770_ChatGPT_Image_Sep_19_2025_03_55_56_PM.png', '2025-11-14 07:20:08', 'Mbombela Campus', '', 'uploads/lease_220202237_1763104770_NSFAS_Lease_Agreement_template_version_1_of_2025_approved_philani_success_gwebu_nsfas_accomodation_solution.pdf'),
(16, 'Tshepiso', '230305222', '230305222@ump.ac.za', 'scrypt:32768:8:1$wHE9C7zAExLbeb1j$5f908f430d308d32d68b59b402e0eeaa1ca079887c3827c504b787bcbb945abf291c9f16b9820a0b59bcfd40707501f2c4b4f988cb09b3975dba4542b224c0e2', '0664218291', 0, 0, 0, 0, 1, 'uploads/card_230305222_1763106818_ChatGPT_Image_Sep_19_2025_03_55_56_PM.png', '2025-11-14 07:54:17', 'Mbombela Campus', '', 'uploads/lease_230305222_1763106818_NSFAS_Lease_Agreement_template_version_1_of_2025_approved_philani_success_gwebu_nsfas_accomodation_solution.pdf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `buyer_id` (`buyer_id`),
  ADD KEY `seller_id` (`seller_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conversation_id` (`conversation_id`),
  ADD KEY `sender_id` (`sender_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `idx_token` (`token`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_expires` (`expires_at`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_rating` (`product_id`,`buyer_id`),
  ADD KEY `seller_id` (`seller_id`),
  ADD KEY `buyer_id` (`buyer_id`);

--
-- Indexes for table `seller_applications`
--
ALTER TABLE `seller_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `seller_reports`
--
ALTER TABLE `seller_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reporter_id` (`reporter_id`),
  ADD KEY `seller_id` (`seller_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `reviewed_by` (`reviewed_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `seller_applications`
--
ALTER TABLE `seller_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `seller_reports`
--
ALTER TABLE `seller_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `conversations`
--
ALTER TABLE `conversations`
  ADD CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `conversations_ibfk_2` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `conversations_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `ratings_ibfk_3` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `seller_applications`
--
ALTER TABLE `seller_applications`
  ADD CONSTRAINT `seller_applications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `seller_reports`
--
ALTER TABLE `seller_reports`
  ADD CONSTRAINT `seller_reports_ibfk_1` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `seller_reports_ibfk_2` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `seller_reports_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `seller_reports_ibfk_4` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
